package com.hieppt.enrich.gnew.navigation

interface NavigationDestination {
    val route: String
    val destination: String
}