package com.hieppt.enrich.gnew.values

const val GNEWS_API_KEY = "412577edaca77aebb24573dbb5483306"
const val GNEWS_BASE_URL = "https://gnews.io/api/v4/"